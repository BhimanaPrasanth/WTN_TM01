package com.wipro.eb.main;

import com.wipro.eb.service.ConnectionService;

public class EBMain {
	public static void main(String a[])
	{
	System.out.println(new ConnectionService().generateBill(250,130,"Domestic"));
	System.out.println(new ConnectionService().generateBill(100,50,"Domestic"));
	System.out.println(new ConnectionService().generateBill(90,70,"Domestic"));;
	System.out.println(new ConnectionService().generateBill(-500,100,"Commercial"));
	System.out.println(new ConnectionService().generateBill(-250,0,"Domestic"));
	System.out.println(new ConnectionService().generateBill(250,130,"Commercial"));
	System.out.println(new ConnectionService().generateBill(100,50,"Commercial"));
	System.out.println(new ConnectionService().generateBill(80,60,"Commercial"));
	System.out.println(new ConnectionService().generateBill(250,130,"wild"));
	System.out.println(new ConnectionService().generateBill(100,50,"soft"));
		}

	}

